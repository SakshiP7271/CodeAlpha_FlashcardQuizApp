document.addEventListener('DOMContentLoaded', () => {
    const addFlashcardButton = document.getElementById('add-flashcard');
    const flashcardList = document.getElementById('flashcards');
    const startQuizButton = document.getElementById('start-quiz');
    const quizSection = document.getElementById('quiz');
    const quizQuestion = document.getElementById('quiz-question');
    const quizAnswerInput = document.getElementById('quiz-answer');
    const submitAnswerButton = document.getElementById('submit-answer');
    const scoreDisplay = document.getElementById('score');
    const currentScoreDisplay = document.getElementById('current-score');

    let flashcards = [];
    let currentQuizIndex = 0;
    let score = 0;

    addFlashcardButton.addEventListener('click', () => {
        const question = document.getElementById('question').value;
        const answer = document.getElementById('answer').value;

        if (question && answer) {
            flashcards.push({ question, answer });
            updateFlashcardList();
            document.getElementById('question').value = '';
            document.getElementById('answer').value = '';
        }
    });

    startQuizButton.addEventListener('click', () => {
        if (flashcards.length === 0) {
            alert('Please add some flashcards first!');
            return;
        }
        currentQuizIndex = 0;
        score = 0;
        scoreDisplay.textContent = '';
        currentScoreDisplay.textContent = '';
        quizSection.classList.remove('hidden');
        showQuestion();
    });

    submitAnswerButton.addEventListener('click', () => {
        const userAnswer = quizAnswerInput.value.trim().toLowerCase();
        const correctAnswer = flashcards[currentQuizIndex].answer.toLowerCase();

        if (userAnswer === correctAnswer) {
            score++;
        }
        quizAnswerInput.value = '';
        currentQuizIndex++;

        if (currentQuizIndex < flashcards.length) {
            showQuestion();
        } else {
            quizSection.classList.add('hidden');
            scoreDisplay.textContent = `Quiz Finished! Your score: ${score}/${flashcards.length}`;
        }

        currentScoreDisplay.textContent = `Current score: ${score}/${currentQuizIndex}`;
    });

    function updateFlashcardList() {
        flashcardList.innerHTML = '';
        flashcards.forEach((flashcard, index) => {
            const li = document.createElement('li');
            li.textContent = `${index + 1}. ${flashcard.question}`;
            flashcardList.appendChild(li);
        });
    }

    function showQuestion() {
        quizQuestion.textContent = flashcards[currentQuizIndex].question;
        quizQuestion.style.backgroundColor = getRandomColor();
    }

    function getRandomColor() {
        const colors = ['#ffeb3b', '#ff9800', '#8bc34a', '#00bcd4', '#e91e63'];
        return colors[Math.floor(Math.random() * colors.length)];
    }
});
